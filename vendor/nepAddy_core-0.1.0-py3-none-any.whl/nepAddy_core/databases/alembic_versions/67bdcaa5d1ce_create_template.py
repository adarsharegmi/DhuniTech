"""create template

Revision ID: 67bdcaa5d1ce
Revises: 
Create Date: 2021-09-06 12:15:03.326564

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "67bdcaa5d1ce"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
