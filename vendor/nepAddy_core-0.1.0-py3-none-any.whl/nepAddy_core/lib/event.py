from pydantic import BaseModel


class Event(BaseModel):
    pass
