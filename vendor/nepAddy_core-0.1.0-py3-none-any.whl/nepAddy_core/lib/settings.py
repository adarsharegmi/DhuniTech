from pydantic import BaseModel


class AbstractSettings(BaseModel):
    pass
