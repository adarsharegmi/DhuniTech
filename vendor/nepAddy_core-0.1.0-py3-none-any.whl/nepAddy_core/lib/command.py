from pydantic import BaseModel


class Command(BaseModel):
    pass
