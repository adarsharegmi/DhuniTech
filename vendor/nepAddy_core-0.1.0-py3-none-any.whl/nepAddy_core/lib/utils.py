import importlib
import re


def resolve_module_version_locations(components, directory):
    migrations_path = []
    for each_component in components:
        component_module = importlib.import_module(each_component + "." + directory)
        path = str(component_module.__path__[0])
        migrations_path.append(path)
    return migrations_path


def resolve_module_version(migrations_path, version_path):
    version_path = version_path + "/alembic_versions"
    for path in migrations_path:
        if version_path in path:
            return path
