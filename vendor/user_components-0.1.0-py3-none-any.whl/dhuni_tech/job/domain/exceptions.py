class DATA_NOT_FOUND(Exception):
    pass

class DUPLICATE_SKILL_FOUND(Exception):
    pass

class DUPLICATE_JOB_FOUND(Exception):
    pass