from uuid import UUID
import sqlalchemy as sa
from dhuni_tech.job.adapters.orm import (
    job,job_skills
)
from nepAddy_core.lib.db_connection import DbConnection



