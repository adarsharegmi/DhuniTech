class DATA_NOT_FOUND(Exception):
    pass

class DUPLICATE_SKILL_FOUND(Exception):
    pass